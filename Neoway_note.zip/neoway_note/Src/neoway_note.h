#ifndef _NEOWAY_NOTE_H_
#define _NEOWAY_NOTE_H_

#include "common.h"

uint8_t NoteInit(void);
#endif
