#ifndef _ALI_IOT_RELAY_H_
#define _ALI_IOT_RELAY_H_

#include "common.h"




uint8_t AliIotInit(void);
void AliIotPro(void);

#endif

